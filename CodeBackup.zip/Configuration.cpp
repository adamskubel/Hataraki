#include "Configuration.hpp"

bool Configuration::CsvLoggingEnabled = false;
