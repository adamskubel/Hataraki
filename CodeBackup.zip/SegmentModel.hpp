#ifndef HATARAKI_BASICMOTION_MODEL_SEGMENTMODEL_HPP_
#define HATARAKI_BASICMOTION_MODEL_SEGMENTMODEL_HPP_

#include "cJSON.h"
#include "Configuration.hpp"


#endif